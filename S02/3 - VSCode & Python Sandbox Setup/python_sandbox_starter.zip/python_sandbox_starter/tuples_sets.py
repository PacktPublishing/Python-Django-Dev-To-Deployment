# A Tuple is a collection which is ordered and unchangeable. Allows duplicate members.
 


# A Set is a collection which is unordered and unindexed. No duplicate members.
