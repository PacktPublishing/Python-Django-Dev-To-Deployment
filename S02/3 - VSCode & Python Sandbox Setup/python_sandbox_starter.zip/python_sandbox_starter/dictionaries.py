# A Dictionary is a collection which is unordered, changeable and indexed. No duplicate members.
